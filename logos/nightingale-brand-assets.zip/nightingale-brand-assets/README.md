# NightingaleMD Brand Assets

Public hosting for NightingaleMD logo files.

## Quick Setup (2 minutes)

1. Go to https://github.com/new
2. Name it `nightingale-brand-assets` → **Public** → Create
3. Click "uploading an existing file" → drag-drop the `logos` folder
4. Commit → Done!

## CDN URLs (use these in shortcuts)

Replace `[USERNAME]` with your GitHub username:

### jsDelivr CDN (recommended - faster, cached globally)

**Full Logo (Shield + Name):**
```
https://cdn.jsdelivr.net/gh/[USERNAME]/nightingale-brand-assets@main/logos/full-logo.png
```

**Shield Only:**
```
https://cdn.jsdelivr.net/gh/[USERNAME]/nightingale-brand-assets@main/logos/shield-only.png
```

### Raw GitHub (backup option)

**Full Logo:** `https://raw.githubusercontent.com/[USERNAME]/nightingale-brand-assets/main/logos/full-logo.png`

**Shield Only:** `https://raw.githubusercontent.com/[USERNAME]/nightingale-brand-assets/main/logos/shield-only.png`

## Brand Colors

| Name | Hex | Usage |
|------|-----|-------|
| Brand Teal | #55B5B8 | Primary/headers |
| Brand Red | #E45740 | Risks/alerts |
| Brand Yellow | #F8CA44 | Callouts/KPIs |
| Neutral Dark | #49545E | Icons/axes |
| Text Primary | #31393F | All body text |
| Text Secondary | #5A6872 | Captions |
| Brand Gray Light | #F2F3F4 | Backgrounds |

---
© NightingaleMD 2025
